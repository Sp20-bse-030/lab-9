/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg9;

/**
 *
 * @author Cyber World
 */
abstract class Student {
    abstract void Takeexams();
    
}
class PHDStudents extends Student{
    public void Takeexams(){
        System.out.println("PhD students take exams by giving his final defense presentation");
        
    }
}
class GradStudent extends Student{
     public void Takeexams(){
        System.out.println("Graduate students gives a written paper");
        
    }
}
