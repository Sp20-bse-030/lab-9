/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg9;
import java.util.Scanner;

/**
 *
 * @author Cyber World
 */
public class Runner_H1_lab9 {
    public static void main(String[]args){
        int d;
        Scanner iput = new Scanner(System.in);
        System.out.println("enter days");
        d = iput.nextInt();
        
        Action a = new Action(3,"Avengers");
        Action b = new Action(2,"Triple Frontier");
        Comedy c = new Comedy(2,"Golmal");
        Comedy w = new Comedy(3,"carry on jatta");
        w.Calcfee(d);
        w.Display();
        w.equals(c);
        
        
}
}
