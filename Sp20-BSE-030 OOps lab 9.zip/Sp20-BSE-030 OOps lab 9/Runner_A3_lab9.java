/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg9;

/**
 *
 * @author Cyber World
 */
public class Runner_A3_lab9 {
    public static void main(String[]args){
        GradStudent s = new GradStudent();
        s.Takeexams();
    }
    
}
